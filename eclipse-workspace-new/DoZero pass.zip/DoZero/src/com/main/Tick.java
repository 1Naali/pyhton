package com.main;

public class Tick {

	public void tick() {
		
		GameMain.map.tick();
		GameMain.p.tick();
	}
}
