package com.nostronido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NostroNidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(NostroNidoApplication.class, args);
	}

}
