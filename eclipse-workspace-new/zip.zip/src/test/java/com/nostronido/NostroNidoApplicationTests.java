package com.nostronido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NostroNidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
